package com.livenow.ch11jpashop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch11JpashopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch11JpashopApplication.class, args);
	}

}
